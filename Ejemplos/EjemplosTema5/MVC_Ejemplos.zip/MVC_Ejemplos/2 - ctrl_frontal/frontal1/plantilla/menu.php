<div style="float:left; width:8em; border-radius: 5px; border:1px solid #aaa; background: #ccffcc; margin-right: 1em;">
    <ul>
        <li><a href='?ctrl=inicio'>Inicio</a></li>
        <li><a href='?ctrl=pag1'>Pag. 1</a></li>
        <li><a href='?ctrl=listar'>Listar</a></li>
        <li><a href='?ctrl=alta'>Alta</a></li>
    </ul>    
</div>

