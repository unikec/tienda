<footer style="background: #ccffcc; clear: both;">
    Pie de página
</footer>

