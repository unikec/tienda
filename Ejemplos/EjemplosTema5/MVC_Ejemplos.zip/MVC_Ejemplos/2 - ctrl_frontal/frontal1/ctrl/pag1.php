<?php
// En un controlador real esto haría más cosas
include(VIEW_PATH.'pag1.php');

