<?php
// En un controlador real esto haría más cosas
include(VIEW_PATH.'inicio.php');

