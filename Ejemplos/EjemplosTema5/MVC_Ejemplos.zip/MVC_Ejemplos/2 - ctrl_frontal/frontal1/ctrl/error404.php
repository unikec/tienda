<?php
/**
 * Página de error. Mostramos directamente la información por comodidad
 * No recomendado para vistas medianamente trabajadas
 */
?>
<h1>Error 404</h1>
<p style='background: #ff9999; border-radius: 5px; padding:2em; margin:1em'>
    Recurso no encontrado
</p>
<p>No existe el fichero: <?=$file?></p>

