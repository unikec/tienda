<div style="float:left; width:8em; border-radius: 5px; border:1px solid #aaa; background: #ccffcc; margin-right: 1em;">
    <h2>Estamos en menu 1</h2>
    <ul>
        <li><a href="?<?=CTRL_VAR?>=<?=CTRL_HOME?>">Inicio</a></li>
        <li><a href="?<?=CTRL_VAR?>=<?=CTRL_PAG1?>">Pag. 1</a></li>
        <li><a href="?<?=CTRL_VAR?>=<?=CTRL_LIST?>">Listar</a></li>
        <li><a href="?<?=CTRL_VAR?>=alta">Alta</a></li>
    </ul>      
</div>

