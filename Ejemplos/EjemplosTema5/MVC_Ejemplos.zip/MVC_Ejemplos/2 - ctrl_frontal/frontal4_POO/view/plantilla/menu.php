<div style="float:left; width:8em; border-radius: 5px; border:1px solid #aaa; background: #ccffcc; margin-right: 1em;">
    <ul>
        <li><a href="<?=Front_Controller::MakeURL('Tareas')?>">Inicio</a></li>
        <li><a href="<?=Front_Controller::MakeURL('Tareas', 'Pag1')?>">Pag. 1</a></li>
        <li><a href="<?=Front_Controller::MakeURL('Tareas', 'Listar')?>">Listar</a></li>
        <li><a href="<?=Front_Controller::MakeURL('Tareas', 'Add')?>">Alta</a></li>
    </ul>    
</div>

