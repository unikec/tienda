<html>
    <head>
        <title>Controlador frontal</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>    
<body>
<?php 
include(TEMPLATE_PATH.'encabezado.php');
include(TEMPLATE_PATH.'menu.php'); 
?>
<h1>Nuestra página de inicioz</h1>
<p>Página inicio que no hace nada</p>
<?php
include(TEMPLATE_PATH.'pie.php');
?>
</body>
</html>
