<header>
    <div style="background: #ccffff; text-align: center; font-size: 2em">
        Encabezado
    </div>
</header>

