<div style="float:left; width:8em; border-radius: 5px; border:1px solid #aaa; background: #ccffcc; margin-right: 1em;">
    <ul>
        <li><a href='inicio.php'>Inicio</a></li>
        <li><a href='pag1.php'>Pag. 1</a></li>
        <li><a href='listar.php'>Listar</a></li>
        <li><a href='new.php'>Alta</a></li>
    </ul>    
</div>

