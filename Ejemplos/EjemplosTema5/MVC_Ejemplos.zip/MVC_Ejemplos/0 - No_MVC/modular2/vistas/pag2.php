<h1>Página 2</h1>
<p>Esta es la página 2</p>
