<h1>Página inicio</h1>
<p>Esta es la página de inicio</p>
<p>Ir a <a href="?page=pag3">página 3</a></p>

