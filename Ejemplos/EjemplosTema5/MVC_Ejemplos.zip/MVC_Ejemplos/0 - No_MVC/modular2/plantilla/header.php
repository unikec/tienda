<div id="header">
</div>
<?php 
/* Observad como los enlaces están referenciados respecto a la URL que 
 * los carga.
 * 
 */
?>
<div id="menu">
    <a href="index.php">Inicio</a>&nbsp;&nbsp;|&nbsp;&nbsp;    
    <a href="?page=pag1">Pag. 1</a>&nbsp;&nbsp;|&nbsp;&nbsp;
    <a href="?page=pag2">Pag. 2</a>&nbsp;&nbsp;|&nbsp;&nbsp;
    <a href="?page=pag3">Pag. 3</a>&nbsp;&nbsp;|&nbsp;&nbsp;
    <a href="?page=pag4">Pag. 4 - Error</a>&nbsp;&nbsp;|&nbsp;&nbsp;
</div>

