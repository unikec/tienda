<ul>
    <li><a href="?page=pag1">Pag.1</a></li>
    <li><a href="?page=pag2">Pag.2</a></li>
    <li><a href="?page=pag3">Pag.3</a></li>
    <li><a href="?page=pag4">Pag.4</a></li>
</ul>

