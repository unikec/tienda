<div id="footer">
    <a href="https://iessansebastian.com/informatica" target="_blank">Desarrollo web entorno servidor</a> I.E.S. San sebastián
</div>
</div>
</body>
</html>