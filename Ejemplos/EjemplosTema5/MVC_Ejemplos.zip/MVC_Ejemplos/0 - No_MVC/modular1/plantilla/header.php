<div id="header">
</div>
<?php 
/* Observad como los enlaces están referenciados respecto a la URL que 
 * los carga.
 * 
 */
?>
<div id="menu">
    <a href="index.php">Inicio</a>&nbsp;&nbsp;|&nbsp;&nbsp;    
    <a href="otrapagina.php">Otra página</a>&nbsp;&nbsp;|&nbsp;&nbsp;
    <a href="#">Services</a>&nbsp;&nbsp;|&nbsp;&nbsp;
    <a href="#">Contact Us</a>
</div>

