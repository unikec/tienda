<?php 
/* Observad como los enlaces están referenciados respecto a la URL que 
 * los carga. 
 * Si entramos por más de una página diferente deberían ser absolutos
 * 
 */
?>
<div id="menu_horizontal">
    <a href="index.php">Inicio</a>&nbsp;&nbsp;|&nbsp;&nbsp;    
    <a href="?page=pag1">Pag. 1</a>&nbsp;&nbsp;|&nbsp;&nbsp;
    <a href="?page=pag2">Pag. 2</a>&nbsp;&nbsp;|&nbsp;&nbsp;
    <a href="?page=pag3">Pag. 3</a>&nbsp;&nbsp;|&nbsp;&nbsp;
    <a href="?page=pag4">Pag. 4 - Error</a>&nbsp;&nbsp;|&nbsp;&nbsp;
</div>

